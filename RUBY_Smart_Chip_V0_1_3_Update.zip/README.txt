RUBY Smart Chip V0.1.3 - Update Package
Contents: index.html (single-file GitHub Pages website)
Install: replace only the existing repository root index.html after approval.
Preserves the existing browser localStorage key and stored configurations.
No GitHub main merge, GitHub Pages deployment, or user data migration was performed.
For safety, export JSON backup before any future deployment.
